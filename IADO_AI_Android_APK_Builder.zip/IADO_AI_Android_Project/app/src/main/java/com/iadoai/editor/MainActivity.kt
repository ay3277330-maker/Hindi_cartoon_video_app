package com.iadoai.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Ink = Color(0xFF151126)
private val Purple = Color(0xFF7652D6)
private val Lavender = Color(0xFFBBA5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IadoApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IadoApp() {
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedTab by remember { mutableStateOf("Home") }
    var brightness by remember { mutableFloatStateOf(1f) }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> selectedUri = uri }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lavender,
            background = Ink,
            surface = Color(0xFF211B35)
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF211B35)) {
                    listOf("Home", "Create", "Projects", "Profile").forEach { item ->
                        NavigationBarItem(
                            selected = selectedTab == item,
                            onClick = { selectedTab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Create" -> Icons.Default.AddCircle
                                        "Projects" -> Icons.Default.Folder
                                        else -> Icons.Default.Person
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("IADO AI", fontSize = 30.sp, fontWeight = FontWeight.Black,
                            color = Color.White)
                        Text("CREATE BEYOND IMAGINATION", fontSize = 10.sp,
                            letterSpacing = 2.sp, color = Lavender)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0xFF342657)) {
                        Text("BETA 1.0", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = Lavender, fontSize = 11.sp)
                    }
                }

                Box(
                    Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF5634A4), Color(0xFF182C58))),
                        RoundedCornerShape(22.dp)
                    ).padding(20.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Your creative world starts here.",
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("फोटो, वीडियो, आवाज और कहानियाँ — एक ही जगह।",
                            color = Color.White.copy(alpha = .82f), fontSize = 13.sp)
                    }
                }

                Text("आप क्या बनाना चाहते हैं?", color = Color.White,
                    fontSize = 19.sp, fontWeight = FontWeight.Bold)

                val tools = listOf(
                    Triple("Photo Magic", "फोटो एडिटिंग", Icons.Default.Photo),
                    Triple("Video Studio", "वीडियो एडिटिंग", Icons.Default.Movie),
                    Triple("Cartoon World", "कार्टून और कहानी", Icons.Default.TheaterComedy),
                    Triple("Voice Studio", "आवाज और नैरेशन", Icons.Default.Mic)
                )
                tools.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { tool ->
                            Card(
                                Modifier.weight(1f).height(112.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF29213F))
                            ) {
                                Column(Modifier.fillMaxSize().padding(14.dp),
                                    verticalArrangement = Arrangement.SpaceBetween) {
                                    Icon(tool.third, contentDescription = null,
                                        tint = Lavender, modifier = Modifier.size(28.dp))
                                    Column {
                                        Text(tool.first, color = Color.White,
                                            fontWeight = FontWeight.Bold)
                                        Text(tool.second, color = Color.LightGray, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Text("Photo workspace", color = Color.White,
                    fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Button(
                    onClick = { picker.launch("image/*") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("मोबाइल से फोटो चुनें")
                }

                if (selectedUri != null) {
                    AsyncImage(
                        model = selectedUri,
                        contentDescription = "Selected photo",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp)
                    )
                    Text("Brightness preview control", color = Color.White)
                    Slider(value = brightness, onValueChange = { brightness = it },
                        valueRange = .5f..1.5f)
                    Text("Brightness: ${(brightness * 100).toInt()}%",
                        color = Color.LightGray, fontSize = 12.sp)
                    Text("नोट: इस शुरुआती संस्करण में स्लाइडर केवल डेमो कंट्रोल है।",
                        color = Color.LightGray, fontSize = 11.sp)
                } else {
                    Surface(
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        color = Color(0xFF211B35),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("आपकी चुनी हुई फोटो यहाँ दिखेगी",
                                color = Color.LightGray, fontSize = 13.sp)
                        }
                    }
                }

                Text("अगले चरण: असली फोटो फिल्टर, वीडियो ट्रिमिंग, AI जनरेशन, हिंदी वॉइस और MP4 एक्सपोर्ट।",
                    color = Color.LightGray, fontSize = 12.sp)
                Text("IADO AI • Made for creators", color = Lavender,
                    modifier = Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp)
            }
        }
    }
}
